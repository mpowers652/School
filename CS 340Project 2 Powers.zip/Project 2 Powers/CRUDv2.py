from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self,username,password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:53993' % (username, password))
        self.database = self.client['AAC']
        
        #only collection is animals
        #will print the collections in the list
        #collections = self.database.list_collection_names()
        #print(collections)
        
        #self.database.animals = self.database['animals']
        
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if bool(data):
            if bool(type(data) is dict):
            	result = self.database['animals'].insert_one(data)  # data should be dictionary
		#print(data)
            else:
                print("Data is not dictionary")
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
    def read(self,field, value):
        #gets field to read and value as input parameter
        
        result = self.database['animals'].find_one({field:value})
        
        #if the value is not null, returns it
        if bool(result):
            print(result)
            return result
        else:
            print("Field/Value pair not found")
            return
    
    #functionality added and tested 4-10-22
    def readAll(self):
        cursor = self.database['animals'].find({})
        return cursor
    
    def readAll(self,field,value):
        #returns cursor object and retrieves every value in list
        if (field == "null" or value == "null"):
            cursor = self.database['animals'].find({},{'_id':False})
            #prints every document in the list
            #for document in cursor:
             #   print (document)
        elif ((type(field) is dict) or (type(value) is dict)):
            cursor = self.database['animals'].find(field,value,{'_id':False})
        else:
            cursor = self.database['animals'].find({field:value},{'_id':False})
        return cursor
    def readFilter(self,fieldA,valueA,fieldB,valueB,fieldC,valueC,fieldD,valueD):
        cursor = self.database['animals'].find({'$and':
                                                [{'animal_type':'Dog'},
                                                 {fieldA:valueA},
                                                 {fieldB:valueB},
                                                 {fieldC:valueC},
                                                 {fieldD:valueD}
                                                ]
                                               }, {'_id':False})
        return cursor
    def update(self,sField, sValue, uField, uValue):
        #first pair is search inputs
        #second pair is update inputs
        
        if bool(type(sField) is not str):
            print("searching field not string, exiting...")
            return
        elif bool(type(sValue) is not str):
            print("searching value not string, exiting...")
            return
        elif bool(type(uField) is not str):
            print("finding field not string, exiting...")
            return 
        elif bool(type(uValue) is not str):
            print("finding value not string, exiting...")
            return
        
        result = self.database.animals.find_one({sField:sValue})
        
        if bool(result):
            print(result)
            result = self.database.animals.update_one({sField:sValue}, {'$set':{uField:uValue}})
            result = self.database.animals.find_one({uField:uValue})            
            print(result)
            return
        else:
            print("Field/Value pair not found")
            return
    
    def delete(self, field, value):
        #receives searching field and value pair to delete
        #checks the type
        if bool(type(field) is not str):
            print("searching field not string, exiting...")
            return
        elif bool(type(value) is not str):
            print("searching value not string, exiting...")
            return 
        
        result = self.database.animals.find_one({field:value})
        
        if bool(result):
            print(result)
            result = self.database.animals.delete_one({field:value})
            return
        else:
            print("Field/Value pair not found")
            return