/*
 * Oviparous.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef OVIPAROUS_H_
#define OVIPAROUS_H_
using namespace std;
#include <iostream>
#include "Animal.h"

class Oviparous : public Animal {
public:
	int m_numOfEggs;
	Oviparous();
	virtual ~Oviparous();
	string getAnimalType();
	virtual bool operator==(Animal rhs);
	int getEggs();
};

#endif /* OVIPAROUS_H_ */
