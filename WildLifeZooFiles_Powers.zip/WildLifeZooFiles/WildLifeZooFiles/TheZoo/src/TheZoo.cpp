#include <iostream>
#include <jni.h>
#include <vector>
#include <iomanip>
#include <fstream>
#include <string> //to convert a string to an integer value
#include "Animal.h"
#include "Bat.h"
#include "Crocodile.h"
#include "Goose.h"
#include "Pelican.h"
#include "SeaLion.h"
#include "Whale.h"
using namespace std;

void GenerateData()               //DO NOT TOUCH CODE IN THIS METHOD
{
     JavaVM *jvm;                      // Pointer to the JVM (Java Virtual Machine)
     JNIEnv *env;                      // Pointer to native interface
                                                              //================== prepare loading of Java VM ============================
     JavaVMInitArgs vm_args;                        // Initialization arguments
     JavaVMOption* options = new JavaVMOption[1];   // JVM invocation options
     options[0].optionString = (char*) "-Djava.class.path=";   // where to find java .class
     vm_args.version = JNI_VERSION_1_6;             // minimum Java version
     vm_args.nOptions = 1;                          // number of options
     vm_args.options = options;
     vm_args.ignoreUnrecognized = false;     // invalid options make the JVM init fail
                                                                          //=============== load and initialize Java VM and JNI interface =============
     jint rc = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);  // YES !!
     delete options;    // we then no longer need the initialisation options.
     if (rc != JNI_OK) {
            // TO DO: error processing...
            cin.get();
            exit(EXIT_FAILURE);
     }
     //=============== Display JVM version =======================================
     cout << "JVM load succeeded: Version ";
     jint ver = env->GetVersion();
     cout << ((ver >> 16) & 0x0f) << "." << (ver & 0x0f) << endl;

     jclass cls2 = env->FindClass("ZooFileWriter");  // try to find the class
     if (cls2 == nullptr) {
            cerr << "ERROR: class not found !";
     }
     else {                                  // if class found, continue
            cout << "Class MyTest found" << endl;
            jmethodID mid = env->GetStaticMethodID(cls2, "createZooFile", "()V");  // find method
            if (mid == nullptr)
                   cerr << "ERROR: method void createZooFile() not found !" << endl;
            else {
                   env->CallStaticVoidMethod(cls2, mid);                      // call method
                   cout << endl;
            }
     }


     jvm->DestroyJavaVM();
     cin.get();
}

//copied one of the java functions and edited it for c++
string padRight(string str, int leng, string stringpadVal) {
   for (int i = str.length(); i < leng; i++)
	   str = str + stringpadVal;
   return str;
}

bool IsDigit(char c) {
	//character numerals are from 48 - 57 in ASCII
	if ((c >= 48) && (c <=57)) {
		return true;
	}
	return false;
}

bool IsNumber(string s) {
	bool tempBool;
	for (unsigned int i = 0; i < s.length(); i++) {
		 tempBool =  IsDigit(s.at(i));
		 //if any of the characters in the string aren't numbers, returns false
		 if (!tempBool) {
			 return tempBool;
		 }
	}
	return tempBool;
}


void AddAnimal(vector<Animal> &animalList)
{
     /*
            TODO: Write proper code to add an animal to your vector (or array)
     */
	string tempSpecies;
	string tempName;
	string tempYoung;
	string tempTrackNum;

	cout << "Enter the species of your animal." << endl;
	cin >> tempSpecies;

	cout << "Enter the name of the animal." << endl;
	cin >> tempName;

	cout << "Enter the tracking number of the animal." << endl;
	cin >> tempTrackNum;

	if (tempSpecies=="Bat") {
		do {
			do {
				cout << "Is the animal nursing? (0 for no or 1 for yes)" << endl;
				//if the value is actually an integer value
				cin >> tempYoung;
			} while (!(IsNumber(tempYoung)));
		} while (((stoi(tempYoung)!= 0 ) || (stoi(tempYoung) != 1)));
		Bat b(tempName, tempTrackNum, stoi(tempYoung));
		animalList.push_back(b);
	}
	else if (tempSpecies == "Crocodile") {
		do {
			cout << "How many eggs?" << endl;
			cin >> tempYoung;
		}while (!IsNumber(tempYoung));
		Crocodile c(tempName, tempTrackNum, stoi(tempYoung));
		animalList.push_back(c);
	}
	else if (tempSpecies == "Goose") {
		do {
			cout << "How many eggs?" << endl;
			cin >> tempYoung;
		}while (!IsNumber(tempYoung));
		Goose g(tempName, tempTrackNum, stoi(tempYoung));
		animalList.push_back(g);
	}
	else if (tempSpecies == "Pelican") {
		do {
			cout << "How many eggs?" << endl;
			cin >> tempYoung;
		}while (!IsNumber(tempYoung));
		Pelican p(tempName, tempTrackNum, stoi(tempYoung));
		animalList.push_back(p);
	}
	else if ((tempSpecies == "Sealion") || (tempSpecies == "SeaLion")) {
		do {
			cout << "Is the animal nursing? (0 for no or 1 for yes)" << endl;
			cin >> tempYoung;
		} while (!IsNumber(tempYoung));
		SeaLion s(tempName, tempTrackNum, stoi(tempYoung));
		animalList.push_back(s);
	}
	else if (tempSpecies == "Whale") {
		do {
			cout << "Is the animal nursing? (0 for no or 1 for yes)" << endl;
			cin >> tempYoung;
		} while (!IsNumber(tempYoung));
		Whale w(tempName, tempTrackNum, stoi(tempYoung));
		animalList.push_back(w);
	}
	cout << tempName << " has been added to the list." << endl;
}

void AddAnimal(Animal &a, vector<Animal> &animalList) {
	animalList.push_back(a);
}

void RemoveAnimal(vector<Animal> &animalList)
{
     /*
            TODO: Write proper code to remove an animal from your vector (or array. Remember to re-allocate proper size if using array)
     */
	string tempName;
	string tempSpecies;
	string tempTrackNum;
	cout << "Enter name of animal to be removed." << endl;
	cin >> tempName;

	cout << "Enter species of animal to be removed." << endl;
	cin >> tempSpecies;

	cout << "Enter tracking number of animal to be removed." << endl;
	cin >> tempTrackNum;

	int animalIndex = -1;
	for(int i = 0; i < animalList.size(); i++) {
		if ((animalList.at(i).m_name == tempName) && (animalList.at(i).m_trackNum == tempTrackNum)
				&& (animalList.at(i).getAnimalSubtype() == tempSpecies)){
			animalIndex = i;
		}
	}
	if(animalIndex >= 0) {
		for(int i = animalIndex; i < (animalList.size()-1); i++) {
			animalList.at(i) = animalList.at(i+1);
		}
		//resize vector  for further use
		animalList.resize(animalList.size() - 1);
		cout << tempName << " has been removed from the list." << endl;
	}
}

void RemoveAnimal(Animal &a, vector<Animal> &animalList) {

	int animalIndex = -1;
	for(int i = 0; i < animalList.size(); i++) {
		if ((animalList.at(i).m_name == a.m_name) && (animalList.at(i).m_trackNum == a.m_trackNum)
				&& (animalList.at(i).getAnimalSubtype() == a.getAnimalSubtype())){
			animalIndex = i;
		}
	}
	if(animalIndex >= 0) {
		for(int i = animalIndex; i < (animalList.size()-1); i++) {
			animalList.at(i) = animalList.at(i+1);
		}
		animalList.resize(animalList.size() - 1);
		cout << a.m_name << " has been removed from the list." << endl;
	}
}

void LoadDataFromFile(vector<Animal> &animalList)
{
     /*
            TODO: Write proper code to load data from input file (generated using JNI) into vector/array.
     */
	ifstream inFs;
	try { //try to open the file
		inFs.open("zoodata.txt"); //will throw exception if 'open file' fails
		if (inFs.is_open()) { // only do this if the file is actually open
		string tempTrackNum;
		string tempName;
		string tempType;
		string tempSpecies;
		int tempEggs;
		int tempNurse;
		string tempInput;
		do {
			//write each line to a string which will be parsed throughout the program
			inFs >> tempInput;
			//the first 6 characters are the tracking number
			tempTrackNum = tempInput.substr(0, 6);
			//the next 15 characters are the name
			tempName = tempInput.substr(6, 15);
			//the next 15 characters are the type (Mammal/Oviparous)
			tempType = tempInput.substr(21, 15);
			//after that is the species (Goose, Pelican etc)
			tempSpecies = tempInput.substr(36, 15);
			//write egg value based on logged value
			if ((tempInput.substr(51, 3) == "0  ") || (tempInput.substr(51, 3) == "00 ") || (tempInput.substr(51, 3) == "000")) {
				tempEggs = 0;
			}
			else {
				/*
				if (((tempInput.substr(53, 1) == " ") && ((tempInput.substr(52, 1) != "0"))||(tempInput.substr(51, 1) != "0"))) {
					if(IsNumber(tempInput.substr(51, 3))) {
						tempEggs = stoi(tempInput.substr(51, 3)); //convert the string value of that 3 digit substring to an egg value
					}
				}*/
				if (IsNumber(tempInput.substr(51,3))) {
					tempEggs = stoi(tempInput.substr(51, 3));
				}
				else {
					cout << "Invalid value for eggs. Eggs set to 0." << endl;
					tempEggs = 0;
				}
			}
			//set nursing value based on logged values
			if (tempInput.substr(54,1) == "0") {
				tempNurse = 0;
			}
			else if (tempInput.substr(54,1) == "1"){
				tempNurse = 1;
			}
			else {
				cout << "Nursing value invalid. Nursing value set to false" << endl;
				tempNurse = 0;
			}

			//with every line in the file, a new animal is created to add to the list
			//switch(tempSpecies) { //create new animals for the list based on species
			//each species set to 15 characters long to allow for proper equality
			if (tempSpecies == "Bat            " ){
				Bat b (tempName, tempTrackNum, tempNurse);
				AddAnimal(b, animalList);
			}
			else if (tempSpecies ==  "Crocodile      " ) {
				Crocodile c(tempName, tempTrackNum, tempEggs);
				AddAnimal(c, animalList);
			}
			else if (tempSpecies == "Goose          " ) {
				Goose g(tempName, tempTrackNum, tempEggs);
				AddAnimal(g, animalList);
			}
			else if (tempSpecies == "Pelican        " ){
				Pelican p(tempName, tempTrackNum, tempEggs);
				AddAnimal(p, animalList);
			}
			else if (tempSpecies ==  "Sealion        " ){
				SeaLion s(tempName, tempTrackNum, tempNurse);
				AddAnimal(s, animalList);
			}
			else if (tempSpecies ==  "Whale          " ){
				Whale w(tempName, tempTrackNum, tempNurse);
				AddAnimal(w, animalList);
			}
			else {
				cout << "Invalid species" << endl;

			}
		} while (!inFs.eof()); //while end of file not reached
		inFs.close(); //close the file
		} //finish the actions if file open
	} catch (exception &e) { //catch the exception thrown if file open failed
		cout <<e.what() << endl;
	}
}


void SaveDataToFile(vector <Animal> &animalList)
{
     /*
            TODO: Write proper code to store vector/array to file.
     */
	ofstream outFs;
	try {
		outFs.open("zoodata.txt"); //will throw error if open file fails
		if (outFs.is_open()) {
			while (animalList.size() > 0) {
				if (animalList.at(0).getAnimalType() == "Mammal") {
					outFs << (animalList.at(0).m_trackNum +
						padRight(animalList.at(0).m_name, 15, " ") +
						padRight(animalList.at(0).getAnimalType(), 15, " ") +
						padRight(animalList.at(0).getAnimalSubtype(), 15, " ") +
						//mammals don't lay eggs
						padRight("0", 3, " ") +
						//convert the value to a string before adding it to the rest of the input line
						to_string(animalList.at(0).getNurse()));
				}
				else {
					outFs << (animalList.at(0).m_trackNum +
						padRight(animalList.at(0).m_name, 15, " ") +
						padRight(animalList.at(0).getAnimalType(), 15, " ") +
						padRight(animalList.at(0).getAnimalSubtype(), 15, " ") +
						//oviparous animals don't nurse

						padRight(to_string(animalList.at(0).getEggs()), 3, " ") + "0");
				}
				//with every iteration, animal list shrinks by one element
				RemoveAnimal(animalList.at(0), animalList);
			}
		}
	} catch (exception e) {
		cout << e.what() << endl;
	}
}



void DisplayMenu()
{
     /*
            TODO: write proper code to display menu to user to select from
     */
	//display a 50 dash line
	cout << setfill('*') << setw(50) << right << "*" << endl;
	//display the word options in the center directly underneath that dashed line
	cout << setfill(' ') << setw(22) << right << "Options" << endl;
	cout << setfill('*') << setw(50) << right << "-" << endl;
	//displays an asterisk followed by 15 spaces and option 1
	cout << "*";
	cout << setfill(' ') << setw(33) << right << "1-Load Animal Data";
	cout << setw(16) << right << "*" << endl;

	cout << "*";
	cout << setfill(' ') << setw(31) << right << "2-Generate Data";
	cout << setw(18) << right << "*" << endl;

	cout << "*";
	cout << setfill(' ') << setw(37) << right << "3-Display Animal Data";
	cout << setw(12) << right << "*" << endl;

	cout << "*";
	cout << setfill(' ') << setw(30) << right << "4-Add Record";
	cout << setw(19) << right << "*" << endl;

	cout << "*";
	cout << setfill(' ') << setw(32) << right << "5-Delete Record";
	cout << setw(17) << right << "*" << endl;

	cout << "*";
	cout << setfill(' ') << setw(33) << right << "6-Save Animal Data";
	cout << setw(16) << right << "*" << endl;
}

void DisplayData(vector <Animal> &animalList) {
	//display 60 asterisks
	cout << setfill('-') << setw(60) << right << "-" << endl;
	cout << setfill(' ');
	for (int i = 0; i < animalList.size(); i++) {
		//display 6 digit tracking number followed by a pipe
		cout << animalList.at(i).m_trackNum;
		cout << "|";
		//display the 15 character name followed by a pipe
		cout << setw(15) << left << animalList.at(i).m_name;
		cout << "|";
		//display the animal type (Mammal, Oviparous) with spaces following it, extending to 15 characters
		//followed by a pipe
		cout << setw(15) << left << animalList.at(i).getAnimalType();
		cout << "|";
		//display the animal subtype (Pelican, Goose, etc) with spaces following, extending to 15 characters
		cout << setw(15) << left << animalList.at(i).getAnimalSubtype();
		cout << "|";
		//display the number of eggs the animal has, allowing for 3 digits
		if (animalList.at(i).getAnimalType() == "Oviparous") {
			cout << setw(3) << left << animalList.at(i).getEggs();
		}
		else {
			cout << setw(3) << left << "0";
		}
		cout << "|";
		//display whether the animal is nursing using either a 0 or 1 and end the line
		if (animalList.at(i).getAnimalType() == "Mammal") {
			cout << animalList.at(i).getNurse() << endl;
		}
		else {
			cout << "0" << endl;
		}
	}
}

int main()
{
	vector <Animal> animals;
	char input;
	do {
		cout << "Please make a selection from the menu below or press x to exit." << endl;
		DisplayMenu();
		cin >> input;

		switch(input) {
		case '1' :
			LoadDataFromFile(animals);
			break;
		case '2' :
			GenerateData();
			break;
		case '3' :
			DisplayData(animals);
			break;
		case '4' :
			AddAnimal(animals);
			break;
		case '5' :
			RemoveAnimal(animals);
			break;
		case '6' :
			SaveDataToFile(animals);
			break;
		case 'x' :
			cout << "Exiting program." << endl;
			break;
		default :
			cout << "Invalid command. Exiting program." << endl;
			break;
		}
	}while (input != 'x');


	return 1;
}
