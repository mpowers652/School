/*
 * Bat.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef BAT_H_
#define BAT_H_
using namespace std;
#include "Mammal.h"

class Bat : public Mammal {
public:
	Bat();
	Bat(string t_name, string t_trackNum, int t_nurse);
	bool operator==(Animal rhs);
	string getAnimalSubtype();
	~Bat();
};

#endif /* BAT_H_ */
