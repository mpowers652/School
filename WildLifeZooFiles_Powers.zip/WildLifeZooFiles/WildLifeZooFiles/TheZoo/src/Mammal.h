/*
 * Mammal.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef MAMMAL_H_
#define MAMMAL_H_
using namespace std;
#include "Animal.h"

class Mammal : public Animal{
public:
	Mammal();
	virtual ~Mammal();
	int m_nurse;
	string getAnimalType();
	virtual string getAnimalSubtype();
	virtual bool operator==(Animal rhs);
	int getNurse();
};

#endif /* MAMMAL_H_ */
