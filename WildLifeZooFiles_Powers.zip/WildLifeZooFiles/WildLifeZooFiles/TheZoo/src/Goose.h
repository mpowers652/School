/*
 * Goose.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef GOOSE_H_
#define GOOSE_H_
using namespace std;
#include "Oviparous.h"

class Goose : public Oviparous{
public:
	Goose();
	Goose(string t_name, string t_trackNum, int t_eggs);
	~Goose();
	string getAnimalSubtype();
	bool operator==(Animal rhs);
};

#endif /* GOOSE_H_ */
