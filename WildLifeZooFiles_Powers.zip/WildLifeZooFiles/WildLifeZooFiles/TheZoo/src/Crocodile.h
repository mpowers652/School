/*
 * Crocodile.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef CROCODILE_H_
#define CROCODILE_H_
using namespace std;
#include "Oviparous.h"

class Crocodile : public Oviparous{
public:
	Crocodile();
	Crocodile(string t_name, string t_trackNum, int t_eggs);
	string getAnimalSubtype();
	~Crocodile();
	bool operator==(Animal rhs);
};

#endif /* CROCODILE_H_ */
