/*
 * Whale.cpp
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#include "Whale.h"
using namespace std;

Whale::Whale() {
	// TODO Auto-generated constructor stub

}

Whale::Whale(string t_name, string t_trackNum, int t_nurse) {
	m_name = t_name;
	m_trackNum = t_trackNum;
	m_nurse = t_nurse;
}

string Whale::getAnimalSubtype(){
	return "Whale";
}

Whale::~Whale() {
	// TODO Auto-generated destructor stub
}


bool Whale::operator==(Animal rhs) {
	if ((this->m_name == rhs.m_name) && (this->m_trackNum == rhs.m_trackNum)) {
		if ((this->m_nurse == rhs.getNurse()) && (this->getAnimalType() == rhs.getAnimalType())) {
			if (this->getAnimalSubtype() == rhs.getAnimalSubtype()) {
				return true;
			}
		}
	}
	return false;
}
