/*
 * Pelican.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef PELICAN_H_
#define PELICAN_H_
using namespace std;
#include "Oviparous.h"

class Pelican : public Oviparous{
public:
	Pelican();
	Pelican(string t_name, string t_trackNum, int t_eggs);
	string getAnimalSubtype();
	~Pelican();
	bool operator==(Animal rhs);
};

#endif /* PELICAN_H_ */
