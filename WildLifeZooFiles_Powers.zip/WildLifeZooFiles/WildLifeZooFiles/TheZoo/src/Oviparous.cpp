/*
 * Oviparous.cpp
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#include "Oviparous.h"
using namespace std;

Oviparous::Oviparous() {
	// TODO Auto-generated constructor stub
	this->m_numOfEggs = 0;
}

string Oviparous::getAnimalType() {
	return "Oviparous";
}

Oviparous::~Oviparous() {
	// TODO Auto-generated destructor stub
}

int Oviparous::getEggs() {
	return m_numOfEggs;
}

bool Oviparous::operator==(Animal rhs) {
	if ((this->m_name == rhs.m_name) && (this->m_trackNum == rhs.m_trackNum)) {
		if ((this->m_numOfEggs == rhs.getEggs()) && (this->getAnimalType() == rhs.getAnimalType())) {
			return true;
		}
	}
	return false;
}

