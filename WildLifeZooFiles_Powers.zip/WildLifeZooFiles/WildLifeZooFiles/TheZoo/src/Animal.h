/*
 * Animal.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef ANIMAL_H_
#define ANIMAL_H_
using namespace std;
#include <iostream>

class Animal {
public:
	string m_name;
	string m_trackNum;
	Animal();
	virtual string getAnimalType();
	virtual string getAnimalSubtype();
	virtual ~Animal();
	virtual int getNurse();
	virtual int getEggs();
	virtual bool operator==(Animal rhs);
};

#endif /* ANIMAL_H_ */
