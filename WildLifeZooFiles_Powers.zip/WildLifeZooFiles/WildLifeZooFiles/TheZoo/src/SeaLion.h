/*
 * SeaLion.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef SEALION_H_
#define SEALION_H_
using namespace std;
#include "Mammal.h"

class SeaLion : public Mammal{
public:
	SeaLion(string t_name, string t_trackNum, int t_nurse);
	SeaLion();
	string getAnimalSubtype();
	~SeaLion();
	bool operator==(Animal rhs);
};

#endif /* SEALION_H_ */
