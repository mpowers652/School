/*
 * SeaLion.cpp
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#include "SeaLion.h"
using namespace std;

SeaLion::SeaLion() {
	// TODO Auto-generated constructor stub

}

SeaLion::SeaLion(string t_name, string t_trackNum, int t_nurse) {
	m_name = t_name;
	m_trackNum = t_trackNum;
	m_nurse = t_nurse;
}

string SeaLion::getAnimalSubtype(){
	return "Sealion";
}

SeaLion::~SeaLion() {
	// TODO Auto-generated destructor stub
}

bool SeaLion::operator==(Animal rhs) {
	if ((this->m_name == rhs.m_name) && (this->m_trackNum == rhs.m_trackNum)) {
		if ((this->m_nurse == rhs.getNurse()) && (this->getAnimalType() == rhs.getAnimalType())) {
			if (this->getAnimalSubtype() == rhs.getAnimalSubtype()) {
				return true;
			}
		}
	}
	return false;
}
