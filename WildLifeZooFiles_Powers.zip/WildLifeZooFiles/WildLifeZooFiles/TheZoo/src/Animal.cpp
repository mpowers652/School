/*
 * Animal.cpp
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#include "Animal.h"
using namespace std;

Animal::Animal() {
	// TODO Auto-generated constructor stub
	string m_name = "NoName";
	string m_trackNum = "000000";

}
Animal::~Animal() {
	// TODO Auto-generated destructor stub
}

int Animal::getNurse() {
	return -1;
}

int Animal::getEggs() {
	return -1;
}

string Animal::getAnimalType() {
	return "noType";
}

string Animal::getAnimalSubtype() {
	return "noSubType";
}

bool Animal::operator==(Animal rhs) {
	if ((this->m_name == rhs.m_name) && (this->m_trackNum == rhs.m_trackNum))
		return true;
	return false;
}
