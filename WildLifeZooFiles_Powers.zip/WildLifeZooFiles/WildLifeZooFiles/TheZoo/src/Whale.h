/*
 * Whale.h
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#ifndef WHALE_H_
#define WHALE_H_
using namespace std;
#include "Mammal.h"

class Whale : public Mammal{
public:
	Whale();
	Whale(string t_name, string t_trackNum, int t_nurse);
	string getAnimalSubtype();
	bool operator==(Animal rhs);
	~Whale();
};

#endif /* WHALE_H_ */
