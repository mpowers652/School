/*
 * Mammal.cpp
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#include "Mammal.h"

using namespace std;

Mammal::Mammal() {
	// TODO Auto-generated constructor stub
	m_nurse = 0;
}

string Mammal::getAnimalType(){
	return "Mammal";
}

Mammal::~Mammal() {
	// TODO Auto-generated destructor stub
}

int Mammal::getNurse() {
	return m_nurse;
}

bool Mammal::operator==(Animal rhs) {
	if ((this->m_name == rhs.m_name) && (this->m_trackNum == rhs.m_trackNum)) {
		if ((this->m_nurse == rhs.getNurse()) && (this->getAnimalType() == rhs.getAnimalType())) {
			return true;
		}
	}
	return false;
}

string Mammal::getAnimalSubtype() {
	return "noSubtype";
}
