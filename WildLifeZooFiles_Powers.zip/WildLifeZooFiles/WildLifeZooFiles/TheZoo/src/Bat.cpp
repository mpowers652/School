/*
 * Bat.cpp
 *
 *  Created on: Nov 14, 2020
 *      Author: 1819695_snhu
 */

#include "Bat.h"
using namespace std;
Bat::Bat() {
	// TODO Auto-generated constructor stub

}

Bat::Bat(string t_name, string t_trackNum, int t_nurse) {
	m_name = t_name;
	m_trackNum = t_trackNum;
	m_nurse = t_nurse;
}

string Bat::getAnimalSubtype()
{
	return "Bat";
}
Bat::~Bat() {
	// TODO Auto-generated destructor stub
}

bool Bat::operator==(Animal rhs) {
	if ((this->m_name == rhs.m_name) && (this->m_trackNum == rhs.m_trackNum)) {
		if ((this->m_nurse == rhs.getNurse()) && (this->getAnimalType() == rhs.getAnimalType())) {
			if (this->getAnimalSubtype() == rhs.getAnimalSubtype()) {
				return true;
			}
		}
	}
	return false;
}
