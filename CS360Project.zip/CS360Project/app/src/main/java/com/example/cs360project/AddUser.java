package com.example.cs360project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddUser extends AppCompatActivity {

    private UserDB mUserDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        mUserDB = UserDB.getInstance(getApplicationContext());
    }

    private void onSubmitClick(View view) {
        addUser(view);
    }
    private void addUser(View view) {
        //define function variables
        String user;
        String pass;
        String passConf;
        String adminUser;
        String adminPass;

        //get resources
        EditText mUserText = findViewById(R.id.newUser);
        EditText mPassText = findViewById(R.id.newPass);
        EditText mPassConf = findViewById(R.id.newPassConfirm);

        EditText mAdminText = findViewById(R.id.adminUser);
        EditText mAdminPass = findViewById(R.id.adminPass);

           //get values of fields
        user = String.valueOf(mUserText.getText());
        pass = String.valueOf(mPassText.getText());
        passConf = String.valueOf(mPassConf.getText());
        adminUser = String.valueOf(mAdminText.getText());
        adminPass = String.valueOf(mAdminPass.getText());

        //check basic conditions, tell user and exit function
        if (!(pass.equals(passConf))) {
            Toast.makeText(getApplicationContext(), "Passwords do not match", Toast.LENGTH_LONG).show();
            return;
        }
        else if (!(mUserDB.userExists(adminUser)) || !(mUserDB.isAdmin(adminUser))) {
            Toast.makeText(getApplicationContext(), "Administrator input is not valid", Toast.LENGTH_LONG).show();
            return;
        }

        else if (mUserDB.addUser(user,pass,false,adminUser,adminPass)) {
            Toast.makeText(getApplicationContext(),"User added successfully",Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            Toast.makeText(getApplicationContext(),"User not added",Toast.LENGTH_SHORT).show();
        }
    }
}