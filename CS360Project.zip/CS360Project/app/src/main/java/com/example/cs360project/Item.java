package com.example.cs360project;

public class Item {
    private long mId;
    private String name;
    private int num;
    private float cost;

    public Item(long id, String itemName, int itemNum, float itemCost) {
        mId = id;
        name = itemName;
        num = itemNum;
        cost = itemCost;
    }

    public float getCost() {
        return cost;
    }

    public String getName() {
        return name;
    }

    public int getNum() {
        return num;
    }

    public long getmId() {
        return mId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public void setmId(long mId) {
        this.mId = mId;
    }

    public void setNum(int num) {
        this.num = num;
    }

}
