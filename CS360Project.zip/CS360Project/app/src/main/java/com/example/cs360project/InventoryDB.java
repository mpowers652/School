package com.example.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;

import java.util.ArrayList;
import java.util.zip.DataFormatException;

public class InventoryDB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    private ArrayList<Item> itemList = new ArrayList<Item>();

    public InventoryDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item name";
        private static final String COL_NUM = "item number";
        private static final String COL_COST = "cost";
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(new StringBuilder().append(
                "create table ").append(InventoryDB.InventoryTable.TABLE).append(" (").append(
                InventoryDB.InventoryTable.COL_ID).append(" integer primary key autoincrement,").append(
                InventoryDB.InventoryTable.COL_ITEM).append(" text, ").append(
                InventoryDB.InventoryTable.COL_NUM).append(" integer, ").append(
                InventoryDB.InventoryTable.COL_COST).append(" float"
        ).toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryDB.InventoryTable.TABLE);
        onCreate(db);
    }

    public boolean itemExists (String name) {
        SQLiteDatabase db = getReadableDatabase();
        //find the matching username
        String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {name});
        if (cursor.moveToFirst()) {
            do {
                //get necessary information
                long id = cursor.getLong(0);
                //id will be -1 if list is 0 size
                if (id != -1) {
                    return true;
                }
            } while (cursor.moveToNext());
        }
        return false;
    }

    public boolean create(String name, int value, float cost) {
        SQLiteDatabase db = getWritableDatabase();
        if (itemExists(name)) {
            //if user is already in system, dont add duplicate
            return false;
        }

        //set values for the columns
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEM, name);
        values.put(InventoryTable.COL_NUM, value);
        values.put(InventoryTable.COL_COST,cost);
        //item added, so exit function and return true
        long id = values.getAsLong(InventoryTable.COL_ID);
        Item e = new Item(id, name, value, cost);
        itemList.add(e);
        return true;
    }

    public void read() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        Log.d("Tag", "Column Headers\tID\tItem name\tItem Counts\tItem Costs");
        if (cursor.moveToFirst()) {
            do {
                //get each of the values for each item.
                long id = cursor.getLong(0);
                String itemName = cursor.getString(1);
                int itemNum = cursor.getInt(2);
                float itemCost = cursor.getFloat(3);

                //separate each item specific with a tab in the database.
                Log.d("Tag", "Item: \t" + id + "\t" + itemName + "\t" + itemNum + "\t" + itemCost);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public boolean update(String name, String field, String value) throws NumberFormatException {
        SQLiteDatabase db = getWritableDatabase();

        if (itemExists(name)) {
            ContentValues values = new ContentValues();
            boolean validResponse = false;
            try {
                do {
                    if (field.equals("name")) {
                        values.put(InventoryTable.COL_ITEM, value);
                        for (Item item: itemList) {
                            if (item.getName().equals(name)) {
                                item.setName(value);
                            }
                        }
                        validResponse = true;
                        return true;
                    }
                    else if (field.equals("number")) {
                        values.put(InventoryTable.COL_NUM, Integer.parseInt(value));
                        validResponse = true;
                        for (Item item: itemList) {
                            if (item.getName().equals(name)) {
                                item.setNum(Integer.parseInt(value));
                            }
                        }
                        return true;
                    }
                    else if (field.equals("cost")) {
                        values.put(InventoryTable.COL_COST, Float.parseFloat(value));
                        validResponse = true;
                        for (Item item: itemList) {
                            if (item.getName().equals(name)) {
                                item.setCost(Float.parseFloat(value));
                            }
                        }
                        return true;
                    }
                } while (!validResponse);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public boolean delete(String name) {
        SQLiteDatabase db = getWritableDatabase();

        if(itemExists(name)) {

            long id;
            String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
            Cursor cursor = db.rawQuery(sql, new String[] {name});
            id = cursor.getLong(0);
            for (Item item:itemList) {
                if (id == item.getmId()) {
                    itemList.remove(item);
                }
            }

            //delete from table
            sql = "delete from " + InventoryTable.TABLE + " where name = ?";
            cursor = db.rawQuery(sql, new String[] {name});
            return true;
        }
        return false;
    }
}
