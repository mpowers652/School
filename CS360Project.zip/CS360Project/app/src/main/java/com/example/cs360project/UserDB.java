package com.example.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class UserDB extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "user.db";
    private static final int VERSION = 1;

    private static UserDB mUserDB;
    private ArrayList<User> userList = new ArrayList();

    public UserDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "username";
        private static final String COL_PASS = "password";
        private static final String COL_ADMIN = "admin status";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(new StringBuilder().append(
                "create table ").append(UserTable.TABLE).append(" (").append(
                        UserTable.COL_ID).append(" integer primary key autoincrement,").append(
                                UserTable.COL_USER).append(" text, ").append(
                                        UserTable.COL_PASS).append(" text, ").append(
                                                //there is no getBoolean function for cursor
                                                //but there is a getInt function
                                                UserTable.COL_ADMIN).append(" integer)").toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public boolean addUser(String user, String pass, boolean admin, String adminUser, String adminPass) {
        SQLiteDatabase db = getWritableDatabase();

        if (userExists(user)) {
            //if user is already in system, dont add duplicate
            return false;
        }
        //add a default admin user to system so they can be used later for testing
        if (user.equals("admin") && pass.equals("password")) {
            ContentValues values = new ContentValues();
            values.put(UserTable.COL_USER, user);
            values.put(UserTable.COL_PASS,pass);
            values.put(UserTable.COL_ADMIN,1);
            User e = new User(user, pass, 1);
            userList.add(e);
            return true;
        }
        //if admin credentials are valid
        if (login(adminUser, adminPass) && isAdmin(adminUser) ) {
            ContentValues values = new ContentValues();
            values.put(UserTable.COL_USER, user);
            values.put(UserTable.COL_PASS,pass);
            values.put(UserTable.COL_ADMIN,admin);
        //user added, so exit function and return true
            int nAdmin;
            if (admin) {
                nAdmin = 1;
            } else {
                nAdmin = 0;
            }
            User e = new User(user, pass, nAdmin);
            userList.add(e);
            return true;
        }
        //
        return false;
    }

    public static UserDB getInstance(Context context) {
        if (mUserDB == null) {
            mUserDB = new UserDB(context);
        }
        return mUserDB;
    }

    public boolean login(String user, String pass) {
        SQLiteDatabase db = getReadableDatabase();
        //find the matching username
        String sql = "select * from " + UserTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {user});
        if (cursor.moveToFirst()) {
            do {
                //get necessary information
                long id = cursor.getLong(0);
                String password = cursor.getString(2);
                //check password received with password input
                if (pass.equals(password)) {
                    return true;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    public boolean userExists(String user) {
        SQLiteDatabase db = getReadableDatabase();
        //find the matching username
        String sql = "select * from " + UserTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {user});
        if (cursor.moveToFirst()) {
            do {
                //get necessary information
                long id = cursor.getLong(0);
                //id will be -1 if list is 0 size
                if (id != -1) {
                    return true;
                }
            } while (cursor.moveToNext());
        }
        return false;
    }

    public boolean isAdmin(String user) {
        SQLiteDatabase db = getReadableDatabase();
        //find the matching username
        String sql = "select * from " + UserTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {user});
        if (cursor.moveToFirst()) {
            do {
                //get necessary information
                long id = cursor.getLong(0);
                boolean bStatus;
                //true reflects a non-zero value in an integer
                //the values being passed will be 1 or 0, anyway
                int nStatus = cursor.getInt(3);
                if (nStatus > 0) {
                    bStatus = true;
                }
                else {
                    bStatus = false;
                }
                return bStatus;
            } while (cursor.moveToNext());
        }
        //if it gets to this point, not admin
        return false;
    }
}
