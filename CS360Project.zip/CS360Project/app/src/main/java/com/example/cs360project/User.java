package com.example.cs360project;

public class User {

    private String username;
    private String password;
    private int isAdmin;

    public User (String user, String pass, int admin) {
        username = user;
        password = pass;
        isAdmin = admin;
    }

    public String getUsername () {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getAdmin() {
        return isAdmin;
    }
}
